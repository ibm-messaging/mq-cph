#!/bin/bash

export BINDINGS=mqc
export QMNAME=PERF0
export HOSTNAME=mqperfes2100
export ITERATIONS="-mg 10000"
export ITERATIONS=
export PORT=1420
export QUEUE=REQUEST1

./cph -nt 1 -ms 25600 -rl 180 -rt 0 -tc PutGet -ss 5 -d $QUEUE -jh $HOSTNAME -jp $PORT -jc SYSTEM.DEF.SVRCONN -jb $QMNAME -jt $BINDINGS -wi 10 $ITERATIONS -pp true -tx true
./cph -nt 2 -ms 25600 -rl 180 -rt 0 -tc PutGet -ss 5 -d $QUEUE -jh $HOSTNAME -jp $PORT -jc SYSTEM.DEF.SVRCONN -jb $QMNAME -jt $BINDINGS -wi 10 $ITERATIONS -pp true -tx true
./cph -nt 4 -ms 25600 -rl 180 -rt 0 -tc PutGet -ss 5 -d $QUEUE -jh $HOSTNAME -jp $PORT -jc SYSTEM.DEF.SVRCONN -jb $QMNAME -jt $BINDINGS -wi 10 $ITERATIONS -pp true -tx true
./cph -nt 8 -ms 25600 -rl 180 -rt 0 -tc PutGet -ss 5 -d $QUEUE -jh $HOSTNAME -jp $PORT -jc SYSTEM.DEF.SVRCONN -jb $QMNAME -jt $BINDINGS -wi 10 $ITERATIONS -pp true -tx true
./cph -nt 16 -ms 25600 -rl 180 -rt 0 -tc PutGet -ss 5 -d $QUEUE -jh $HOSTNAME -jp $PORT -jc SYSTEM.DEF.SVRCONN -jb $QMNAME -jt $BINDINGS -wi 10 $ITERATIONS -pp true -tx true
